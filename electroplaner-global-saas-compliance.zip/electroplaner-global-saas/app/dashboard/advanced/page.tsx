'use client';
import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase';
import { countryStandards, generateSingleLineSchematic } from '@/lib/advanced-features';

const countries = Object.keys(countryStandards);

export default function AdvancedDashboard(){
  const [user,setUser]=useState<any>(null);
  const [sub,setSub]=useState<any>(null);
  const [country,setCountry]=useState('International');
  const [cadText,setCadText]=useState('Kitchen socket socket light switch panel EV charger');
  const [cadOut,setCadOut]=useState<any>(null);
  const [bimOut,setBimOut]=useState<any>(null);
  const [pv,setPv]=useState({country:'International',roofAreaM2:80,pvWpPerM2:200,annualYieldKwhPerKw:950,wallboxKw:11,simultaneousFactor:0.7,buildingPeakLoadKw:12});
  const [pvOut,setPvOut]=useState<any>(null);
  const [agentOut,setAgentOut]=useState<any>(null);

  useEffect(()=>{(async()=>{const s=createClient(); const {data}=await s.auth.getUser(); if(!data.user){location.href='/auth/login';return;} setUser(data.user); const {data:subscription}=await s.from('subscriptions').select('*').eq('user_id',data.user.id).maybeSingle(); setSub(subscription);})()},[]);
  const active=sub?.status==='active'||sub?.status==='trialing';
  const schematic = useMemo(()=>generateSingleLineSchematic({projectName:'Advanced demo',country,circuits:[{name:'Kitchen appliances',loadWatts:7200,voltage:230,phases:'1',lengthMeters:26},{name:'EV charger',loadWatts:11000,voltage:400,phases:'3',lengthMeters:32},{name:'Lighting floor 1',loadWatts:1200,voltage:230,phases:'1',lengthMeters:38}]}),[country]);

  async function callApi(path:string, body:any, setter:(v:any)=>void){const res=await fetch(path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)}); setter(await res.json());}
  async function saveModule(type:string, input:any, result:any){const s=createClient(); if(!user||!result) return; await s.from('advanced_projects').insert({user_id:user.id,module:type,country,input,result}); alert('Advanced module saved.');}

  return <main className="container section">
    <p><Link href="/dashboard">← Back to dashboard</Link></p>
    <h2>Advanced Engineering Suite</h2>
    <p className="muted">CAD import, automatic single-line diagrams, BIM object data, PV/wallbox planning, AI-agent workflows, mobile readiness and international standards.</p>
    {!active && <div className="card"><h3>Professional subscription required</h3><p className="muted">Advanced modules are locked until the Stripe subscription is active.</p></div>}
    {active && <div className="advancedGrid">
      <section className="card"><span className="kicker">International norms</span><h3>Country workflow</h3><select value={country} onChange={e=>setCountry(e.target.value)}>{countries.map(c=><option key={c}>{c}</option>)}</select><pre>{JSON.stringify((countryStandards as any)[country],null,2)}</pre></section>
      <section className="card"><span className="kicker">CAD import</span><h3>Symbol detection workflow</h3><textarea rows={5} value={cadText} onChange={e=>setCadText(e.target.value)} /><button className="btn primary" onClick={()=>callApi('/api/advanced/cad',{fileName:'demo.dxf',fileText:cadText,country},setCadOut)}>Analyze CAD text</button>{cadOut&&<><pre>{JSON.stringify(cadOut,null,2)}</pre><button className="btn" onClick={()=>saveModule('cad',cadText,cadOut)}>Save CAD analysis</button></>}</section>
      <section className="card"><span className="kicker">Single-line diagram</span><h3>Automatic circuit schematic</h3><p className="muted">Generated from circuit loads and local workflow assumptions.</p><pre>{schematic.mainLine}\n{schematic.circuits.map(c=>c.line).join('\n')}</pre><button className="btn" onClick={()=>saveModule('schematic',{country},schematic)}>Save schematic</button></section>
      <section className="card"><span className="kicker">BIM</span><h3>IFC/Revit-ready data model</h3><button className="btn primary" onClick={()=>callApi('/api/advanced/bim',{country},setBimOut)}>Generate BIM library</button>{bimOut&&<><pre>{JSON.stringify(bimOut,null,2)}</pre><button className="btn" onClick={()=>saveModule('bim',{country},bimOut)}>Save BIM library</button></>}</section>
      <section className="card"><span className="kicker">PV + Wallbox</span><h3>Solar and EV planning</h3><div className="form">{Object.entries(pv).map(([k,v])=>k==='country'?<select key={k} value={pv.country} onChange={e=>setPv({...pv,country:e.target.value})}>{countries.map(c=><option key={c}>{c}</option>)}</select>:<input key={k} value={v as any} placeholder={k} onChange={e=>setPv({...pv,[k]:Number(e.target.value)})}/>)}</div><button className="btn primary" onClick={()=>callApi('/api/advanced/pv-wallbox',pv,setPvOut)}>Calculate PV / EV</button>{pvOut&&<><pre>{JSON.stringify(pvOut,null,2)}</pre><button className="btn" onClick={()=>saveModule('pv-wallbox',pv,pvOut)}>Save PV/wallbox plan</button></>}</section>
      <section className="card"><span className="kicker">AI agents</span><h3>Planning agent workflow</h3><button className="btn primary" onClick={()=>callApi('/api/advanced/agents',{loads:[{name:'Heat pump',powerWatts:5000},{name:'EV',powerWatts:11000},{name:'Kitchen',powerWatts:7200}]},setAgentOut)}>Run agents</button>{agentOut&&<><pre>{JSON.stringify(agentOut,null,2)}</pre><button className="btn" onClick={()=>saveModule('agents',{country},agentOut)}>Save agent run</button></>}</section>
      <section className="card"><span className="kicker">Mobile app</span><h3>PWA-ready field workflow</h3><p className="muted">The app now includes a mobile entry route, responsive cards and a manifest-ready structure for installation on phones. Native iOS/Android can later reuse the same Supabase and API backend.</p><Link className="btn" href="/mobile">Open mobile preview</Link></section>
    </div>}
  </main>
}
