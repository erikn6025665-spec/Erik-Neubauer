'use client';
import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase';
import { calculateElectrical } from '@/lib/calculations';

const numberFields = ['voltage','powerWatts','lengthMeters','powerFactor','maxVoltageDropPercent','rcdMilliAmps','ambientTemperatureC','groupingFactor','faultLoopImpedanceOhm','requiredDisconnectTimeMs','measuredDisconnectTimeMs','prospectiveShortCircuitKa','protectiveDeviceBreakingCapacityKa','upstreamBreakerAmps','mainBreakerAmps'];

export default function Dashboard(){
 const [user,setUser]=useState<any>(null);
 const [sub,setSub]=useState<any>(null);
 const [out,setOut]=useState<any>(null);
 const [form,setForm]=useState({
  projectName:'Office renovation',
  country:'International',
  voltage:230,
  phases:'1',
  powerWatts:7400,
  lengthMeters:28,
  powerFactor:0.95,
  maxVoltageDropPercent:3,
  installationMethod:'standard',
  circuitUse:'socket',
  rcdGfciType:'A',
  rcdMilliAmps:30,
  earthingSystem:'TN-S',
  ambientTemperatureC:30,
  groupingFactor:1,
  faultLoopImpedanceOhm:'',
  requiredDisconnectTimeMs:400,
  measuredDisconnectTimeMs:'',
  prospectiveShortCircuitKa:'',
  protectiveDeviceBreakingCapacityKa:'',
  upstreamBreakerAmps:'',
  mainBreakerAmps:'',
  localCodeConfirmed:false
 } as any);

 useEffect(()=>{(async()=>{const s=createClient(); const {data}=await s.auth.getUser(); if(!data.user){location.href='/auth/login';return;} setUser(data.user); const {data:sub}=await s.from('subscriptions').select('*').eq('user_id',data.user.id).maybeSingle(); setSub(sub);})()},[]);
 async function checkout(){const res=await fetch('/api/stripe/checkout',{method:'POST'}); const data=await res.json(); if(data.url) location.href=data.url; else alert(data.error||'Checkout unavailable');}
 function preparedForm(){
  const copy:any = {...form};
  for (const key of numberFields) if (copy[key] === '') copy[key] = null;
  return copy;
 }
 async function calc(e:React.FormEvent){e.preventDefault(); const clean=preparedForm(); const result=calculateElectrical(clean); setOut(result); const s=createClient(); await s.from('projects').insert({user_id:user.id,name:form.projectName,country:form.country,input:clean,result});}
 const active=sub?.status==='active'||sub?.status==='trialing';
 const update = (key:string, value:any) => setForm({...form,[key]:value});
 return <main className="container section"><h2>Professional Dashboard</h2><p><a className="btn" href="/dashboard/advanced">Open Advanced Engineering Suite</a></p><p className="muted">Logged in as {user?.email}</p>{!active&&<div className="card"><h3>Subscription required</h3><p className="muted">Activate Professional to unlock saved calculations and project history.</p><button className="btn primary" onClick={checkout}>Subscribe with Stripe</button></div>}{active&&<div className="grid grid2"><div className="card"><h3>Electrical calculation + safety precheck</h3><form className="form" onSubmit={calc}>
  <input value={form.projectName} placeholder="Project name" onChange={e=>update('projectName',e.target.value)}/>
  <input value={form.country} placeholder="Country / standard workflow" onChange={e=>update('country',e.target.value)}/>
  <div className="grid grid2"><input value={form.voltage} placeholder="Voltage V" onChange={e=>update('voltage',Number(e.target.value))}/><select value={form.phases} onChange={e=>update('phases',e.target.value)}><option value="1">1-phase</option><option value="3">3-phase</option></select></div>
  <div className="grid grid2"><input value={form.powerWatts} placeholder="Power W" onChange={e=>update('powerWatts',Number(e.target.value))}/><input value={form.lengthMeters} placeholder="Length m" onChange={e=>update('lengthMeters',Number(e.target.value))}/></div>
  <div className="grid grid2"><input value={form.powerFactor} placeholder="Power factor" onChange={e=>update('powerFactor',Number(e.target.value))}/><input value={form.maxVoltageDropPercent} placeholder="Max voltage drop %" onChange={e=>update('maxVoltageDropPercent',Number(e.target.value))}/></div>
  <label>Safety & compliance precheck</label>
  <div className="grid grid2"><select value={form.circuitUse} onChange={e=>update('circuitUse',e.target.value)}><option value="general">General</option><option value="socket">Socket/outlet</option><option value="lighting">Lighting</option><option value="wet_room">Wet room</option><option value="outdoor">Outdoor</option><option value="ev_charger">EV charger</option><option value="pv_inverter">PV inverter</option><option value="heat_pump">Heat pump</option><option value="critical_load">Critical load</option></select><select value={form.rcdGfciType} onChange={e=>update('rcdGfciType',e.target.value)}><option value="unknown">RCD/GFCI unknown</option><option value="none">None</option><option value="AC">Type AC</option><option value="A">Type A</option><option value="F">Type F</option><option value="B">Type B</option><option value="GFCI">GFCI</option><option value="RCBO">RCBO</option></select></div>
  <div className="grid grid2"><input value={form.rcdMilliAmps} placeholder="RCD/GFCI mA" onChange={e=>update('rcdMilliAmps',Number(e.target.value))}/><select value={form.earthingSystem} onChange={e=>update('earthingSystem',e.target.value)}><option value="unknown">Earthing unknown</option><option value="TN-S">TN-S</option><option value="TN-C-S">TN-C-S</option><option value="TT">TT</option><option value="IT">IT</option><option value="TN-C">TN-C</option></select></div>
  <div className="grid grid2"><select value={form.installationMethod} onChange={e=>update('installationMethod',e.target.value)}><option value="standard">Standard</option><option value="conduit_wall">Conduit/wall</option><option value="insulation">In insulation</option><option value="cable_tray">Cable tray</option><option value="underground">Underground</option><option value="outdoor">Outdoor</option><option value="high_temperature">High temperature</option></select><input value={form.ambientTemperatureC} placeholder="Ambient temperature °C" onChange={e=>update('ambientTemperatureC',Number(e.target.value))}/></div>
  <div className="grid grid2"><input value={form.groupingFactor} placeholder="Grouping factor 0.3-1" onChange={e=>update('groupingFactor',Number(e.target.value))}/><input value={form.faultLoopImpedanceOhm} placeholder="Fault-loop impedance Ω" onChange={e=>update('faultLoopImpedanceOhm',e.target.value)}/></div>
  <div className="grid grid2"><input value={form.requiredDisconnectTimeMs} placeholder="Required disconnect ms" onChange={e=>update('requiredDisconnectTimeMs',Number(e.target.value))}/><input value={form.measuredDisconnectTimeMs} placeholder="Measured disconnect ms" onChange={e=>update('measuredDisconnectTimeMs',e.target.value)}/></div>
  <div className="grid grid2"><input value={form.prospectiveShortCircuitKa} placeholder="Prospective short-circuit kA" onChange={e=>update('prospectiveShortCircuitKa',e.target.value)}/><input value={form.protectiveDeviceBreakingCapacityKa} placeholder="Device breaking capacity kA" onChange={e=>update('protectiveDeviceBreakingCapacityKa',e.target.value)}/></div>
  <div className="grid grid2"><input value={form.upstreamBreakerAmps} placeholder="Upstream breaker A" onChange={e=>update('upstreamBreakerAmps',e.target.value)}/><input value={form.mainBreakerAmps} placeholder="Main breaker A" onChange={e=>update('mainBreakerAmps',e.target.value)}/></div>
  <label className="checkline"><input type="checkbox" checked={form.localCodeConfirmed} onChange={e=>update('localCodeConfirmed',e.target.checked)}/> Local code review confirmed by qualified person</label>
  <button className="btn primary">Calculate & save</button></form></div><div className="card"><h3>Result</h3>{out?<><div className="grid grid2"><div className="metric"><b>{out.currentAmps} A</b><span>Current</span></div><div className="metric"><b>{out.suggestedBreaker}</b><span>Breaker</span></div><div className="metric"><b>{out.suggestedCable}</b><span>Cable</span></div><div className="metric"><b>{out.voltageDropPercent}%</b><span>Voltage drop</span></div></div><div className="notice"><b>Safety status:</b> {out.safetyPrecheck.status}<br/>{out.disclaimer}</div><div className="findings">{out.safetyPrecheck.findings.map((f:any)=><div className={`finding ${f.status}`} key={f.item}><b>{f.item} — {f.status}</b><p>{f.message}</p><small>{f.recommendation}</small></div>)}</div></>:<p className="muted">Run a calculation.</p>}</div></div>}</main>
}
