import { NextResponse } from 'next/server';
import { createServerSupabase } from '@/lib/supabase-server';
import { stripe } from '@/lib/stripe';

export async function POST(request: Request) {
  const origin = request.headers.get('origin') || process.env.NEXT_PUBLIC_APP_URL!;
  const supabase = await createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    customer_email: user.email!,
    client_reference_id: user.id,
    line_items: [{ price: process.env.NEXT_PUBLIC_STRIPE_PRICE_PRO_MONTHLY!, quantity: 1 }],
    success_url: `${origin}/dashboard?checkout=success`,
    cancel_url: `${origin}/pricing?checkout=cancelled`,
    allow_promotion_codes: true
  });
  return NextResponse.json({ url: session.url });
}
