import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { stripe } from '@/lib/stripe';

export async function POST(request: Request) {
  const body = await request.text();
  const sig = request.headers.get('stripe-signature')!;
  let event;
  try { event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!); }
  catch (err:any) { return NextResponse.json({ error: err.message }, { status: 400 }); }
  const admin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);
  if (event.type === 'checkout.session.completed') {
    const s:any = event.data.object;
    await admin.from('subscriptions').upsert({ user_id: s.client_reference_id, stripe_customer_id: s.customer, stripe_subscription_id: s.subscription, status: 'active', plan: 'professional' }, { onConflict: 'user_id' });
  }
  if (event.type === 'customer.subscription.updated' || event.type === 'customer.subscription.deleted') {
    const sub:any = event.data.object;
    await admin.from('subscriptions').update({ status: sub.status }).eq('stripe_subscription_id', sub.id);
  }
  return NextResponse.json({ received: true });
}
