import { NextResponse } from 'next/server';
import { runPlanningAgents } from '@/lib/advanced-features';

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  return NextResponse.json(runPlanningAgents(body));
}
