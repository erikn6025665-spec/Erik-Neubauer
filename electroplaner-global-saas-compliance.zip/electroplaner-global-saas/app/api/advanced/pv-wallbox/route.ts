import { NextResponse } from 'next/server';
import { planPvWallbox } from '@/lib/advanced-features';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    return NextResponse.json(planPvWallbox(body));
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
}
