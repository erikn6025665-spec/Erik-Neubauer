'use client';
import { useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase';

export default function Register(){
 const [company,setCompany]=useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [msg,setMsg]=useState('');
 async function submit(e:React.FormEvent){e.preventDefault(); const supabase=createClient(); const {error}=await supabase.auth.signUp({email,password,options:{data:{company_name:company},emailRedirectTo:`${location.origin}/auth/callback`}}); if(error){setMsg(error.message);return;} setMsg('Account created. Check your email, then log in and subscribe.');}
 return <main className="container section"><div className="card" style={{maxWidth:560,margin:'40px auto'}}><h2>Create company account</h2><p className="muted">After signup, activate the Pro subscription to unlock the calculator.</p><form className="form" onSubmit={submit}><input placeholder="Company name" value={company} onChange={e=>setCompany(e.target.value)} required/><input type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required/><input type="password" placeholder="Password" minLength={8} value={password} onChange={e=>setPassword(e.target.value)} required/><button className="btn primary">Create account</button>{msg&&<p className="muted">{msg}</p>}<Link href="/auth/login">Already have an account?</Link></form></div></main>
}
