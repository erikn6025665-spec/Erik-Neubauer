'use client';
import { useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase';

export default function Login(){
 const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [msg,setMsg]=useState('');
 async function submit(e:React.FormEvent){e.preventDefault(); const supabase=createClient(); const {error}=await supabase.auth.signInWithPassword({email,password}); if(error){setMsg(error.message);return;} location.href='/dashboard';}
 return <main className="container section"><div className="card" style={{maxWidth:520,margin:'40px auto'}}><h2>Login</h2><p className="muted">Sign in with your company account.</p><form className="form" onSubmit={submit}><input type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required/><input type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} required/><button className="btn primary">Login</button>{msg&&<p className="muted">{msg}</p>}<Link href="/auth/register">Create account</Link></form></div></main>
}
