import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'ElektroPlaner Global AI',
  description: 'Professional electrical pre-design SaaS with real calculations, subscriptions and secure project storage.'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
