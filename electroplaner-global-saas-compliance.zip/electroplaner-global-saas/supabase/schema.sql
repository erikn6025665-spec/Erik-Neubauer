create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  company_name text,
  country text,
  role text default 'owner',
  created_at timestamptz default now()
);

create table if not exists public.subscriptions (
  user_id uuid primary key references auth.users(id) on delete cascade,
  stripe_customer_id text,
  stripe_subscription_id text unique,
  plan text default 'professional',
  status text default 'incomplete',
  current_period_end timestamptz,
  updated_at timestamptz default now()
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  name text not null,
  country text default 'International',
  input jsonb not null,
  result jsonb not null,
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.subscriptions enable row level security;
alter table public.projects enable row level security;

create policy "profiles own read" on public.profiles for select using (auth.uid() = id);
create policy "profiles own update" on public.profiles for update using (auth.uid() = id);
create policy "subscriptions own read" on public.subscriptions for select using (auth.uid() = user_id);
create policy "projects own all" on public.projects for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, company_name) values (new.id, new.raw_user_meta_data->>'company_name');
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();


create table if not exists public.advanced_projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  module text not null,
  country text default 'International',
  input jsonb not null,
  result jsonb not null,
  created_at timestamptz default now()
);

alter table public.advanced_projects enable row level security;
create policy "advanced projects own all" on public.advanced_projects for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
