import { z } from 'zod';

export const safetyComplianceSchema = z.object({
  country: z.string().default('International'),
  phases: z.enum(['1','3']).default('1'),
  voltage: z.coerce.number().positive().default(230),
  currentAmps: z.coerce.number().nonnegative(),
  suggestedBreakerAmps: z.coerce.number().nullable().optional(),
  cableSectionMm2: z.coerce.number().positive(),
  voltageDropPercent: z.coerce.number().nonnegative(),
  maxVoltageDropPercent: z.coerce.number().min(1).max(10).default(3),
  circuitUse: z.enum(['general','socket','lighting','wet_room','outdoor','ev_charger','pv_inverter','heat_pump','critical_load']).default('general'),
  rcdGfciType: z.enum(['unknown','none','AC','A','F','B','GFCI','RCBO']).default('unknown'),
  rcdMilliAmps: z.coerce.number().nonnegative().default(30),
  earthingSystem: z.enum(['unknown','TN-S','TN-C-S','TT','IT','TN-C']).default('unknown'),
  installationMethod: z.enum(['standard','conduit_wall','insulation','cable_tray','underground','outdoor','high_temperature']).default('standard'),
  ambientTemperatureC: z.coerce.number().min(-30).max(80).default(30),
  groupingFactor: z.coerce.number().min(0.3).max(1).default(1),
  faultLoopImpedanceOhm: z.coerce.number().nonnegative().optional().nullable(),
  requiredDisconnectTimeMs: z.coerce.number().positive().default(400),
  measuredDisconnectTimeMs: z.coerce.number().positive().optional().nullable(),
  prospectiveShortCircuitKa: z.coerce.number().nonnegative().optional().nullable(),
  protectiveDeviceBreakingCapacityKa: z.coerce.number().nonnegative().optional().nullable(),
  upstreamBreakerAmps: z.coerce.number().nonnegative().optional().nullable(),
  mainBreakerAmps: z.coerce.number().nonnegative().optional().nullable(),
  localCodeConfirmed: z.boolean().default(false)
});

export type SafetyComplianceInput = z.infer<typeof safetyComplianceSchema>;

export type SafetyFinding = {
  item: string;
  status: 'pass' | 'warning' | 'review' | 'fail';
  message: string;
  recommendation: string;
};

function finding(item: string, status: SafetyFinding['status'], message: string, recommendation: string): SafetyFinding {
  return { item, status, message, recommendation };
}

function overall(findings: SafetyFinding[]) {
  if (findings.some(f => f.status === 'fail')) return 'blocked_review_required';
  if (findings.some(f => f.status === 'review')) return 'engineering_review_required';
  if (findings.some(f => f.status === 'warning')) return 'conditional_precheck';
  return 'precheck_ok';
}

function rcdRequired(use: SafetyComplianceInput['circuitUse']) {
  return ['socket','wet_room','outdoor','ev_charger','pv_inverter'].includes(use);
}

export function runSafetyCompliancePrecheck(raw: SafetyComplianceInput) {
  const data = safetyComplianceSchema.parse(raw);
  const findings: SafetyFinding[] = [];

  if (rcdRequired(data.circuitUse)) {
    if (data.rcdGfciType === 'unknown' || data.rcdGfciType === 'none') {
      findings.push(finding('RCD/GFCI', 'review', `${data.circuitUse} circuits usually require a defined residual-current protection concept.`, 'Select and document the required RCD/GFCI/RCBO type according to the local standard and equipment leakage/DC-current profile.'));
    } else if (data.circuitUse === 'ev_charger' && !['A','B','F','RCBO','GFCI'].includes(data.rcdGfciType)) {
      findings.push(finding('RCD/GFCI', 'warning', `Selected ${data.rcdGfciType} may be unsuitable for EV charging.`, 'Check EV charger manufacturer requirements, DC leakage detection and local code before installation.'));
    } else {
      findings.push(finding('RCD/GFCI', 'pass', `${data.rcdGfciType} protection is documented for this precheck.`, 'Verify exact type, rating and coordination on site.'));
    }
  } else {
    findings.push(finding('RCD/GFCI', data.rcdGfciType === 'unknown' ? 'warning' : 'pass', data.rcdGfciType === 'unknown' ? 'RCD/GFCI concept is not documented.' : `${data.rcdGfciType} protection is documented.`, 'Confirm whether residual-current protection is mandatory for this circuit in the target country.'));
  }

  if (data.voltageDropPercent > data.maxVoltageDropPercent) {
    findings.push(finding('Voltage drop', 'fail', `${data.voltageDropPercent}% exceeds the configured ${data.maxVoltageDropPercent}% limit.`, 'Increase cable section, reduce route length, split the circuit or change supply concept.'));
  } else if (data.voltageDropPercent > data.maxVoltageDropPercent * 0.85) {
    findings.push(finding('Voltage drop', 'warning', `${data.voltageDropPercent}% is close to the configured limit.`, 'Keep a design reserve and verify actual route length, conductor material and load profile.'));
  } else {
    findings.push(finding('Voltage drop', 'pass', `${data.voltageDropPercent}% is within the configured predesign limit.`, 'Confirm final voltage-drop limits from the local standard and client specification.'));
  }

  if (data.earthingSystem === 'unknown') {
    findings.push(finding('Earthing system', 'review', 'Earthing system is not defined.', 'Define TN-S, TN-C-S, TT, IT or local equivalent before selecting protection and disconnection strategy.'));
  } else if (data.earthingSystem === 'TN-C') {
    findings.push(finding('Earthing system', 'review', 'TN-C has special restrictions and separation requirements.', 'Verify PEN conductor rules, downstream separation and local restrictions with a licensed professional.'));
  } else {
    findings.push(finding('Earthing system', 'pass', `${data.earthingSystem} is documented.`, 'Verify bonding, grounding electrode, PE/PEN sizing and local utility requirements.'));
  }

  const tempDerating = data.ambientTemperatureC > 40 ? 0.87 : data.ambientTemperatureC > 35 ? 0.94 : 1;
  const installationPenalty = ['insulation','underground','outdoor','high_temperature'].includes(data.installationMethod) ? 0.85 : 1;
  const effectiveCapacityFactor = Number((tempDerating * installationPenalty * data.groupingFactor).toFixed(2));
  if (effectiveCapacityFactor < 0.65) {
    findings.push(finding('Installation method / grouping / temperature', 'review', `Combined capacity factor is ${effectiveCapacityFactor}.`, 'Recalculate ampacity with the exact installation method, grouping, insulation, soil/ambient temperature and manufacturer tables.'));
  } else if (effectiveCapacityFactor < 0.85) {
    findings.push(finding('Installation method / grouping / temperature', 'warning', `Combined capacity factor is ${effectiveCapacityFactor}.`, 'Check whether the cable section must be increased after derating.'));
  } else {
    findings.push(finding('Installation method / grouping / temperature', 'pass', `Combined capacity factor is ${effectiveCapacityFactor}.`, 'Still verify final derating with approved tables for the target jurisdiction.'));
  }

  if (data.faultLoopImpedanceOhm == null || data.measuredDisconnectTimeMs == null) {
    findings.push(finding('Disconnection conditions', 'review', 'Fault-loop impedance or disconnection time is missing.', 'Measure/calculate Zs, prospective fault current and disconnection time before installation release.'));
  } else if (data.measuredDisconnectTimeMs > data.requiredDisconnectTimeMs) {
    findings.push(finding('Disconnection conditions', 'fail', `${data.measuredDisconnectTimeMs} ms exceeds required ${data.requiredDisconnectTimeMs} ms.`, 'Change protective device, cable size, earthing/protection concept or circuit length until disconnection is compliant.'));
  } else {
    findings.push(finding('Disconnection conditions', 'pass', `${data.measuredDisconnectTimeMs} ms is within the configured limit.`, 'Confirm measurement method and local maximum disconnection time.'));
  }

  if (data.prospectiveShortCircuitKa == null || data.protectiveDeviceBreakingCapacityKa == null) {
    findings.push(finding('Short-circuit rating', 'review', 'Prospective short-circuit current or device breaking capacity is missing.', 'Confirm Ik/PSCC at the installation point and use protective devices with sufficient rated breaking capacity.'));
  } else if (data.prospectiveShortCircuitKa > data.protectiveDeviceBreakingCapacityKa) {
    findings.push(finding('Short-circuit rating', 'fail', `${data.prospectiveShortCircuitKa} kA exceeds device capacity ${data.protectiveDeviceBreakingCapacityKa} kA.`, 'Select a device with higher breaking capacity or redesign upstream protection.'));
  } else {
    findings.push(finding('Short-circuit rating', 'pass', `${data.protectiveDeviceBreakingCapacityKa} kA device capacity covers ${data.prospectiveShortCircuitKa} kA prospective current.`, 'Verify manufacturer data and installation category.'));
  }

  if (data.upstreamBreakerAmps && data.suggestedBreakerAmps && data.upstreamBreakerAmps <= data.suggestedBreakerAmps) {
    findings.push(finding('Selectivity', 'review', `Upstream ${data.upstreamBreakerAmps} A is not clearly selective above downstream ${data.suggestedBreakerAmps} A.`, 'Check time-current curves, cascading/backup protection tables and selective coordination.'));
  } else if (data.mainBreakerAmps && data.suggestedBreakerAmps && data.suggestedBreakerAmps > data.mainBreakerAmps) {
    findings.push(finding('Selectivity', 'fail', `Suggested breaker ${data.suggestedBreakerAmps} A exceeds main breaker ${data.mainBreakerAmps} A.`, 'Reduce circuit load, split circuits or upgrade supply after utility approval.'));
  } else {
    findings.push(finding('Selectivity', 'warning', 'Selectivity cannot be fully proven from rating values alone.', 'Use manufacturer selectivity tables and short-circuit calculations for final coordination.'));
  }

  if (!data.localCodeConfirmed) {
    findings.push(finding('Local regulations', 'review', `${data.country} local requirements are not confirmed.`, 'Have the design checked against local electrical code, utility rules, permits, labels, inspection and documentation duties.'));
  } else {
    findings.push(finding('Local regulations', 'pass', `${data.country} local-code review is marked as confirmed.`, 'Keep evidence, inspection notes and final sign-off documentation.'));
  }

  return {
    status: overall(findings),
    disclaimer: 'Automated safety/compliance precheck only. This is not an execution approval and does not replace a licensed electrician, local code review, measurements or inspection.',
    assumptions: {
      country: data.country,
      circuitUse: data.circuitUse,
      earthingSystem: data.earthingSystem,
      effectiveCapacityFactor
    },
    findings
  };
}
