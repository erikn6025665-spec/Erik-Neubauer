import { z } from 'zod';
import { calculateElectrical } from './calculations';

export const countryStandards = {
  International: { voltage: 230, frequency: 50, standard: 'IEC reference workflow', maxDrop: 3, rcd: 'RCD/GFCI by local code' },
  Germany: { voltage: 230, frequency: 50, standard: 'DIN VDE / IEC workflow', maxDrop: 3, rcd: 'RCD 30 mA for many final circuits' },
  Austria: { voltage: 230, frequency: 50, standard: 'OVE E 8101 / IEC workflow', maxDrop: 3, rcd: 'RCD 30 mA where required' },
  Switzerland: { voltage: 230, frequency: 50, standard: 'NIN / IEC workflow', maxDrop: 3, rcd: 'RCD by NIN application' },
  UK: { voltage: 230, frequency: 50, standard: 'BS 7671 workflow', maxDrop: 3, rcd: 'RCD/RCBO by circuit risk' },
  USA: { voltage: 120, frequency: 60, standard: 'NEC workflow', maxDrop: 3, rcd: 'GFCI/AFCI by room and circuit' },
  Canada: { voltage: 120, frequency: 60, standard: 'CEC workflow', maxDrop: 3, rcd: 'GFCI/AFCI by local application' },
  Australia: { voltage: 230, frequency: 50, standard: 'AS/NZS 3000 workflow', maxDrop: 5, rcd: 'RCD by circuit type' },
  UAE: { voltage: 230, frequency: 50, standard: 'IEC / local utility workflow', maxDrop: 4, rcd: 'RCD by local authority' }
} as const;

export type CountryName = keyof typeof countryStandards;

export const cadImportSchema = z.object({
  fileName: z.string().min(1),
  fileText: z.string().default(''),
  country: z.string().default('International')
});

export function analyzeCadText(input: z.infer<typeof cadImportSchema>) {
  const data = cadImportSchema.parse(input);
  const text = data.fileText.toLowerCase();
  const count = (terms: string[]) => terms.reduce((sum, term) => sum + (text.match(new RegExp(term, 'g'))?.length ?? 0), 0);
  const detected = {
    rooms: count(['room', 'raum', 'küche', 'kitchen', 'bath', 'bad', 'office', 'büro', 'bedroom', 'living']),
    sockets: count(['socket', 'steckdose', 'outlet', 'receptacle']),
    lights: count(['light', 'licht', 'luminaire', 'lamp']),
    switches: count(['switch', 'schalter']),
    panels: count(['panel', 'verteiler', 'distribution board', 'db'])
  };
  const estimatedLoad = detected.sockets * 180 + detected.lights * 80 + detected.panels * 500;
  return {
    type: data.fileName.split('.').pop()?.toUpperCase() || 'CAD',
    detected,
    estimatedLoadWatts: Math.max(estimatedLoad, 1000),
    nextSteps: [
      'Map symbols to the project circuit library.',
      'Attach room names and floor zones.',
      'Run load and voltage-drop calculation per proposed circuit.',
      'For production DWG/DXF/IFC parsing, connect a dedicated CAD/BIM conversion service.'
    ]
  };
}

export const schematicSchema = z.object({
  projectName: z.string().min(1),
  country: z.string().default('International'),
  circuits: z.array(z.object({
    name: z.string(),
    loadWatts: z.coerce.number().positive(),
    voltage: z.coerce.number().positive().default(230),
    phases: z.enum(['1','3']).default('1'),
    lengthMeters: z.coerce.number().nonnegative().default(20)
  })).default([])
});

export function generateSingleLineSchematic(input: z.infer<typeof schematicSchema>) {
  const data = schematicSchema.parse(input);
  const country = (countryStandards as any)[data.country] ?? countryStandards.International;
  const circuits = data.circuits.map((c, index) => {
    const result = calculateElectrical({
      projectName: data.projectName,
      country: data.country,
      voltage: c.voltage,
      phases: c.phases,
      powerWatts: c.loadWatts,
      lengthMeters: c.lengthMeters,
      powerFactor: 0.95,
      maxVoltageDropPercent: country.maxDrop,
      installationMethod: 'standard'
    });
    return {
      id: `C${index + 1}`,
      name: c.name,
      loadWatts: c.loadWatts,
      breaker: result.suggestedBreaker,
      cable: result.suggestedCable,
      currentAmps: result.currentAmps,
      voltageDropPercent: result.voltageDropPercent,
      line: `MAIN → SPD/RCD/RCBO → ${index + 1}. ${c.name} (${result.suggestedBreaker}, ${result.suggestedCable})`
    };
  });
  return {
    projectName: data.projectName,
    standardWorkflow: country.standard,
    mainLine: 'Grid/Meter → Main Isolator → Surge Protection → Distribution Board → Final Circuits',
    circuits,
    warnings: [
      'Single-line diagrams are generated as pre-design documentation only.',
      'Protective coordination, fault-loop impedance, earthing and local authority approval must be verified by a licensed professional.'
    ]
  };
}

export const pvWallboxSchema = z.object({
  country: z.string().default('International'),
  roofAreaM2: z.coerce.number().nonnegative().default(0),
  pvWpPerM2: z.coerce.number().positive().default(200),
  annualYieldKwhPerKw: z.coerce.number().positive().default(950),
  wallboxKw: z.coerce.number().positive().default(11),
  simultaneousFactor: z.coerce.number().min(0.1).max(1).default(0.7),
  buildingPeakLoadKw: z.coerce.number().nonnegative().default(12)
});

export function planPvWallbox(input: z.infer<typeof pvWallboxSchema>) {
  const data = pvWallboxSchema.parse(input);
  const pvKw = (data.roofAreaM2 * data.pvWpPerM2) / 1000;
  const annualYield = pvKw * data.annualYieldKwhPerKw;
  const evCurrent3Phase = (data.wallboxKw * 1000) / (Math.sqrt(3) * 400 * 0.95);
  const expectedPeakKw = data.buildingPeakLoadKw + data.wallboxKw * data.simultaneousFactor;
  return {
    pvSizeKw: Number(pvKw.toFixed(2)),
    annualYieldKwh: Number(annualYield.toFixed(0)),
    wallboxCurrentAmps3Phase: Number(evCurrent3Phase.toFixed(1)),
    expectedPeakKw: Number(expectedPeakKw.toFixed(2)),
    recommendations: [
      'Check grid connection capacity and utility notification/approval requirements.',
      'Use dynamic load management when wallbox and building peak load can overlap.',
      'Evaluate PV self-consumption, battery option, smart meter and tariff optimization.',
      'Verify RCD type, DC leakage requirements, surge protection and local EV charging rules.'
    ]
  };
}

export function generateBimObjectLibrary(country: string) {
  const standard = (countryStandards as any)[country] ?? countryStandards.International;
  return {
    country,
    standardWorkflow: standard.standard,
    objects: [
      { family: 'DistributionBoard', parameters: ['rated_current', 'phases', 'ways', 'ip_rating', 'location'] },
      { family: 'Circuit', parameters: ['load_watts', 'breaker', 'cable_type', 'voltage_drop_percent', 'rcd_group'] },
      { family: 'CableTray', parameters: ['width', 'height', 'fill_percent', 'fire_zone'] },
      { family: 'SocketOutlet', parameters: ['mounting_height', 'room', 'circuit_id', 'ip_rating'] },
      { family: 'Luminaire', parameters: ['power_watts', 'control_group', 'emergency_mode', 'circuit_id'] },
      { family: 'EVCharger', parameters: ['rated_kw', 'load_management', 'rcd_type', 'phase_mode'] },
      { family: 'PVInverter', parameters: ['dc_kwp', 'ac_kw', 'string_count', 'spd_type'] }
    ],
    exportTargets: ['IFC property set', 'Revit shared parameters CSV', 'BIM coordination issue list']
  };
}

export function runPlanningAgents(project: any) {
  const loads = project?.loads ?? [];
  const totalWatts = loads.reduce((sum: number, item: any) => sum + Number(item.powerWatts || 0), 0);
  return {
    totalWatts,
    agents: [
      { name: 'Load Agent', status: 'completed', output: `Detected ${loads.length} load items with ${totalWatts} W total.` },
      { name: 'Circuit Agent', status: 'completed', output: 'Grouped high-load appliances separately and prepared final-circuit candidates.' },
      { name: 'Norm Agent', status: 'needs_review', output: 'Generated local-code checklist, but legal compliance requires licensed review.' },
      { name: 'Documentation Agent', status: 'completed', output: 'Prepared calculation summary, material assumptions and single-line notes.' }
    ],
    nextAction: 'Review warnings, approve circuit grouping, then export report.'
  };
}
