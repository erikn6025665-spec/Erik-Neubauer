import { z } from 'zod';
import { runSafetyCompliancePrecheck } from './safety-compliance';

export const calculationSchema = z.object({
  projectName: z.string().min(1),
  country: z.string().default('International'),
  voltage: z.coerce.number().positive().default(230),
  phases: z.enum(['1','3']).default('1'),
  powerWatts: z.coerce.number().positive(),
  lengthMeters: z.coerce.number().nonnegative().default(0),
  powerFactor: z.coerce.number().min(0.1).max(1).default(0.95),
  maxVoltageDropPercent: z.coerce.number().min(1).max(10).default(3),
  installationMethod: z.enum(['standard','conduit_wall','insulation','cable_tray','underground','outdoor','high_temperature']).default('standard'),
  circuitUse: z.enum(['general','socket','lighting','wet_room','outdoor','ev_charger','pv_inverter','heat_pump','critical_load']).default('general'),
  rcdGfciType: z.enum(['unknown','none','AC','A','F','B','GFCI','RCBO']).default('unknown'),
  rcdMilliAmps: z.coerce.number().nonnegative().default(30),
  earthingSystem: z.enum(['unknown','TN-S','TN-C-S','TT','IT','TN-C']).default('unknown'),
  ambientTemperatureC: z.coerce.number().min(-30).max(80).default(30),
  groupingFactor: z.coerce.number().min(0.3).max(1).default(1),
  faultLoopImpedanceOhm: z.coerce.number().nonnegative().optional().nullable(),
  requiredDisconnectTimeMs: z.coerce.number().positive().default(400),
  measuredDisconnectTimeMs: z.coerce.number().positive().optional().nullable(),
  prospectiveShortCircuitKa: z.coerce.number().nonnegative().optional().nullable(),
  protectiveDeviceBreakingCapacityKa: z.coerce.number().nonnegative().optional().nullable(),
  upstreamBreakerAmps: z.coerce.number().nonnegative().optional().nullable(),
  mainBreakerAmps: z.coerce.number().nonnegative().optional().nullable(),
  localCodeConfirmed: z.boolean().default(false)
});

export type CalculationInput = z.infer<typeof calculationSchema>;

const copperResistivity = 0.0175; // Ohm * mm² / m at 20°C, simplified pre-design value
const standardSections = [1.5,2.5,4,6,10,16,25,35,50,70,95,120,150,185,240];
const breakerSteps = [6,10,13,16,20,25,32,40,50,63,80,100,125,160,200,250,315,400];

export function calculateElectrical(input: CalculationInput) {
  const data = calculationSchema.parse(input);
  const current = data.phases === '3'
    ? data.powerWatts / (Math.sqrt(3) * data.voltage * data.powerFactor)
    : data.powerWatts / (data.voltage * data.powerFactor);
  const breaker = breakerSteps.find(x => x >= current * 1.15) ?? null;
  const voltageDropVolts = data.voltage * (data.maxVoltageDropPercent / 100);
  const multiplier = data.phases === '3' ? Math.sqrt(3) : 2;
  const sectionByDrop = (multiplier * copperResistivity * data.lengthMeters * current) / Math.max(voltageDropVolts, 0.1);
  const sectionByCurrent = current <= 16 ? 2.5 : current <= 25 ? 4 : current <= 32 ? 6 : current <= 50 ? 10 : current <= 63 ? 16 : current <= 100 ? 25 : current <= 125 ? 35 : current <= 160 ? 50 : current <= 200 ? 70 : current <= 250 ? 95 : 120;
  const requiredSection = Math.max(sectionByDrop, sectionByCurrent);
  const cableSection = standardSections.find(x => x >= requiredSection) ?? 240;
  const actualDrop = (multiplier * copperResistivity * data.lengthMeters * current) / cableSection;
  const dropPercent = (actualDrop / data.voltage) * 100;
  const safetyPrecheck = runSafetyCompliancePrecheck({
    country: data.country,
    phases: data.phases,
    voltage: data.voltage,
    currentAmps: Number(current.toFixed(2)),
    suggestedBreakerAmps: breaker,
    cableSectionMm2: cableSection,
    voltageDropPercent: Number(dropPercent.toFixed(2)),
    maxVoltageDropPercent: data.maxVoltageDropPercent,
    circuitUse: data.circuitUse,
    rcdGfciType: data.rcdGfciType,
    rcdMilliAmps: data.rcdMilliAmps,
    earthingSystem: data.earthingSystem,
    installationMethod: data.installationMethod,
    ambientTemperatureC: data.ambientTemperatureC,
    groupingFactor: data.groupingFactor,
    faultLoopImpedanceOhm: data.faultLoopImpedanceOhm,
    requiredDisconnectTimeMs: data.requiredDisconnectTimeMs,
    measuredDisconnectTimeMs: data.measuredDisconnectTimeMs,
    prospectiveShortCircuitKa: data.prospectiveShortCircuitKa,
    protectiveDeviceBreakingCapacityKa: data.protectiveDeviceBreakingCapacityKa,
    upstreamBreakerAmps: data.upstreamBreakerAmps,
    mainBreakerAmps: data.mainBreakerAmps,
    localCodeConfirmed: data.localCodeConfirmed
  });
  return {
    ...data,
    currentAmps: Number(current.toFixed(2)),
    suggestedBreaker: breaker ? `${breaker} A` : 'Engineering review required',
    suggestedBreakerAmps: breaker,
    suggestedCable: `${data.phases === '3' ? '5' : '3'} × ${cableSection} mm² Cu`,
    cableSectionMm2: cableSection,
    voltageDropVolts: Number(actualDrop.toFixed(2)),
    voltageDropPercent: Number(dropPercent.toFixed(2)),
    riskLevel: dropPercent > data.maxVoltageDropPercent || !breaker || safetyPrecheck.status !== 'precheck_ok' ? 'review' : 'ok',
    safetyPrecheck,
    checks: safetyPrecheck.findings.map(f => `${f.item}: ${f.message}`),
    disclaimer: safetyPrecheck.disclaimer
  };
}
