import Link from 'next/link';
export function Nav(){return <nav className="nav"><div className="container navin"><Link className="logo" href="/">⚡ ElektroPlaner Global</Link><div className="navlinks"><Link href="/#features">Features</Link><Link href="/pricing">Pricing</Link><Link href="/auth/login">Login</Link><Link className="btn primary" href="/auth/register">Start Pro</Link></div></div></nav>}
